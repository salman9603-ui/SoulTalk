#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
find "$ROOT" -name '*.js' -print0 | xargs -0 -n1 node --check
find "$ROOT" -name '*.json' -print0 | xargs -0 -n1 python -m json.tool >/dev/null
python - <<'PY'
from pathlib import Path
p=Path('app/build.gradle').read_text()
assert "versionName '3.2.0'" in p
assert "versionCode 32" in p
assert "startsWith('https://')" in p
print('SoulTalk release verification: PASS')
PY
