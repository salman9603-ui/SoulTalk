# SoulTalk v37

- Calls now have a ringing phase before billing starts.
- Host must explicitly accept before the call becomes active.
- Billing clock starts at `acceptedAt`, not when the caller taps Call.
- Caller cancellation while ringing costs ₹0.
- Unanswered calls expire after 45 seconds with ₹0 charge.
- Host rejection emits a caller-only call-ended event with ₹0 charge.
- Caller UI billing estimate starts only after call acceptance.
- WebRTC signaling remains server-authoritative for call state.
