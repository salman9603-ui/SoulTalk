# SoulTalk v24

## Billing correctness fix
- Server billing now applies the configured **started-minute** rule consistently at call end.
- A 61-second call is billed as 2 minutes when the caller has enough wallet balance.
- If the caller only has enough balance for 1 minute, the server caps the call at 1 billable minute and the wallet-exhaustion guard ends it.
- Host earnings remain ₹2 per billed minute.
- Billing remains server-authoritative; client duration is never trusted for charging.
