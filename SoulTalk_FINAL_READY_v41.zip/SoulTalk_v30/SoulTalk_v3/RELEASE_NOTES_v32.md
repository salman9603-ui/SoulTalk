# SoulTalk v32

- Added client handling for server-authoritative `call:ended` events.
- When wallet exhaustion ends an active call, the caller UI now closes, WebRTC resources are cleaned up, wallet refreshes, and the user receives the final charge notice.
- Synced the updated frontend into the server and Android asset copies.
