# SoulTalk v39

- Fixed host reject validation so a ringing call can be rejected before acceptance.
- Caller now remains in a zero-charge ringing state until the host accepts.
- Voice/WebRTC setup and per-minute display start only after server-side call acceptance.
- Caller receives server-side accept/no-answer/reject events through the authenticated user channel.
- Android version bumped to 3.5.0 (versionCode 35).
- This package still requires a real HTTPS backend, payment gateway, TURN service, signing key, and Android SDK/Gradle for production release.
