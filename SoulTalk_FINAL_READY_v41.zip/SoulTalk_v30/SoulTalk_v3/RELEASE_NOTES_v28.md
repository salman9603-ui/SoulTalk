# SoulTalk v28

- Added server-side validation for report reasons.
- Added duplicate pending-report throttling (same user/room within 30 seconds).
- Frontend now reports report-submission errors instead of always showing success.
- Synced frontend copy used by the server package.
