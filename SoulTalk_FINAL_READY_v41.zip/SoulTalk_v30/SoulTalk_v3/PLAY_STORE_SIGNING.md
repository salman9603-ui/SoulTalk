# SoulTalk Play Store signing

This package does not contain a keystore or passwords. Create/store the upload keystore securely outside the source tree.

## Release build

Set these environment variables (or pass matching `-P` properties):
- `SOULTALK_API_BASE=https://your-api-domain`
- `SOULTALK_SIGNING=true`
- `SOULTALK_KEYSTORE_PATH=/secure/path/soultalk-upload.jks`
- `SOULTALK_KEYSTORE_PASSWORD=...`
- `SOULTALK_KEY_ALIAS=soultalk`
- `SOULTALK_KEY_PASSWORD=...`

Then run:

```bash
./gradlew :app:bundleRelease -PSOULTALK_API_BASE="$SOULTALK_API_BASE" -PSOULTALK_SIGNING=true -PSOULTALK_KEYSTORE_PATH="$SOULTALK_KEYSTORE_PATH" -PSOULTALK_KEYSTORE_PASSWORD="$SOULTALK_KEYSTORE_PASSWORD" -PSOULTALK_KEY_ALIAS="$SOULTALK_KEY_ALIAS" -PSOULTALK_KEY_PASSWORD="$SOULTALK_KEY_PASSWORD"
```

The resulting AAB is under `app/build/outputs/bundle/release/`.

Never commit a keystore, passwords, API secrets, payment keys, or TURN credentials into this ZIP or Git.
