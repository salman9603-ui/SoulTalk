#!/usr/bin/env bash
set -euo pipefail
API_BASE="${SOULTALK_API_BASE:-${1:-}}"
if [[ -z "$API_BASE" || ! "$API_BASE" =~ ^https:// ]]; then
  echo "ERROR: Set SOULTALK_API_BASE to an HTTPS production API URL." >&2
  exit 2
fi
if ! command -v java >/dev/null 2>&1; then echo "ERROR: JDK 17+ is required." >&2; exit 3; fi
if [[ ! -x ./gradlew ]]; then
  echo "ERROR: Gradle wrapper is missing. Open this project in Android Studio or install Gradle 8.7+." >&2
  exit 4
fi
./gradlew :app:bundleRelease -PSOULTALK_API_BASE="$API_BASE"
