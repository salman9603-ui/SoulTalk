#!/usr/bin/env bash
set -u
ok=1
command -v java >/dev/null 2>&1 && echo "PASS: Java" || { echo "FAIL: Java missing"; ok=0; }
command -v gradle >/dev/null 2>&1 && echo "PASS: Gradle" || { echo "FAIL: Gradle missing"; ok=0; }
if [ -n "${ANDROID_HOME:-}" ] && [ -d "$ANDROID_HOME" ]; then echo "PASS: ANDROID_HOME=$ANDROID_HOME"; elif [ -n "${ANDROID_SDK_ROOT:-}" ] && [ -d "$ANDROID_SDK_ROOT" ]; then echo "PASS: ANDROID_SDK_ROOT=$ANDROID_SDK_ROOT"; else echo "FAIL: Android SDK path missing"; ok=0; fi
if [ "$ok" -eq 1 ]; then echo "BUILD ENVIRONMENT READY"; else echo "BUILD ENVIRONMENT NOT READY"; exit 1; fi
