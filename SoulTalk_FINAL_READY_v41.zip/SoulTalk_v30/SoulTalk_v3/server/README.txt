SoulTalk repaired backend v16 foundation.

Run:
  npm install
  JWT_SECRET="replace-with-a-long-random-secret" npm start

Features: JWT auth, profiles, wallet demo ledger, approved host discovery, server-started calls, server-timed billing, host earning ledger, chat, reports, account deletion.

IMPORTANT: recharge is demo-only. Production payments, WebRTC/provider voice media, KYC/payouts, GST/tax, anti-fraud and Play Billing/policy review are still required before launch.

ADMIN SETUP
Set ADMIN_EMAIL and ADMIN_PASSWORD (8+ chars) before first production start to bootstrap an admin account. Never commit real credentials.
