const crypto=require('crypto');const express=require('express');const http=require('http');const path=require('path');const fs=require('fs');const bcrypt=require('bcryptjs');const jwt=require('jsonwebtoken');const {Server}=require('socket.io');
const {billCall}=require('../../production_backend/call_billing');
const app=express();const server=http.createServer(app);const io=new Server(server);const PORT=process.env.PORT||3000;const IS_PROD=process.env.NODE_ENV==='production';const JWT_SECRET=process.env.JWT_SECRET||'soultalk-dev-secret-change-me';if(IS_PROD&&JWT_SECRET==='soultalk-dev-secret-change-me')throw new Error('JWT_SECRET must be configured in production.');
app.set('trust proxy',1);
const allowedOrigin=process.env.CORS_ORIGIN||'*';
const authHits=new Map();
function authRateLimit(req,res,next){const key=(req.ip||'unknown')+':'+req.path;const now=Date.now();const hit=authHits.get(key);if(!hit||now-hit.start>60000){authHits.set(key,{start:now,count:1});return next()}hit.count++;if(hit.count>20)return res.status(429).json({error:'Too many authentication attempts. Try again later.'});next()}
setInterval(()=>{const cutoff=Date.now()-60000;for(const [k,v] of authHits)if(v.start<cutoff)authHits.delete(k)},60000).unref();
app.use((req,res,next)=>{const origin=req.headers.origin;if(allowedOrigin==='*'||!origin||origin===allowedOrigin)res.setHeader('Access-Control-Allow-Origin',allowedOrigin==='*'?'*':origin);res.setHeader('Vary','Origin');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Access-Control-Allow-Headers','Content-Type, Authorization, X-SoulTalk-Signature');res.setHeader('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS');if(req.method==='OPTIONS')return res.sendStatus(204);next();});
const DATA=path.join(__dirname,'data.json');let db=fs.existsSync(DATA)?JSON.parse(fs.readFileSync(DATA,'utf8')):{users:[],messages:[],calls:[],reports:[],wallets:{},ledger:[],paymentOrders:[],withdrawals:[]};db.users=db.users||[];db.messages=db.messages||[];db.calls=db.calls||[];db.reports=db.reports||[];db.wallets=db.wallets||{};db.ledger=db.ledger||[];db.paymentOrders=db.paymentOrders||[];db.withdrawals=db.withdrawals||[];
async function bootstrapAdmin(){const email=String(process.env.ADMIN_EMAIL||'').trim().toLowerCase();const password=String(process.env.ADMIN_PASSWORD||'');if(!email||password.length<8)return;let u=db.users.find(x=>x.email===email);if(!u){u={id:crypto.randomUUID(),email,password:await bcrypt.hash(password,10),name:'SoulTalk Admin',about:'',role:'admin',hostStatus:'none',createdAt:new Date().toISOString()};db.users.push(u);db.wallets[u.id]=0;save();console.log('SoulTalk admin bootstrap user created: '+email)}else if(u.role!=='admin'){u.role='admin';save();console.log('SoulTalk admin role enabled: '+email)}}
function save(){const tmp=DATA+'.tmp';fs.writeFileSync(tmp,JSON.stringify(db,null,2),{mode:0o600});fs.renameSync(tmp,DATA)}function token(u){return jwt.sign({id:u.id},JWT_SECRET,{expiresIn:'30d'})}function auth(req,res,next){try{const p=jwt.verify((req.headers.authorization||'').replace(/^Bearer /,''),JWT_SECRET);req.user=db.users.find(u=>u.id===p.id);if(!req.user)return res.status(401).json({error:'Unauthorized'});next()}catch{return res.status(401).json({error:'Unauthorized'})}}
function adminOnly(req,res,next){if(!req.user||req.user.role!=='admin')return res.status(403).json({error:'Admin access required.'});next();}
app.use(express.json({limit:'256kb'}));app.get('/api/health',(req,res)=>res.json({ok:true,service:'soultalk-api',time:new Date().toISOString()}));app.use(express.static(path.join(__dirname,'..','public')));
app.post('/api/register',authRateLimit,async(req,res)=>{const email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||'');if(!email||password.length<6)return res.status(400).json({error:'Email and 6+ character password required.'});if(db.users.some(u=>u.email===email))return res.status(409).json({error:'Email already registered.'});const u={id:crypto.randomUUID(),email,password:await bcrypt.hash(password,10),name:'',about:'',role:'user',hostStatus:'none',createdAt:new Date().toISOString()};db.users.push(u);db.wallets[u.id]=0;save();res.json({token:token(u)})});
app.post('/api/login',authRateLimit,async(req,res)=>{const u=db.users.find(x=>x.email===String(req.body.email||'').trim().toLowerCase());if(!u||!(await bcrypt.compare(String(req.body.password||''),u.password)))return res.status(401).json({error:'Invalid email or password.'});res.json({token:token(u)})});
app.get('/api/me',auth,(req,res)=>{const {password,...u}=req.user;res.json(u)});app.put('/api/profile',auth,(req,res)=>{req.user.name=String(req.body.name||'').slice(0,80);req.user.about=String(req.body.about||'').slice(0,300);save();res.json({ok:true})});
app.get('/api/wallet',auth,(req,res)=>res.json({balancePaise:db.wallets[req.user.id]||0,balance:(db.wallets[req.user.id]||0)/100}));
app.get('/api/wallet/ledger',auth,(req,res)=>res.json(db.ledger.filter(x=>x.userId===req.user.id).slice(-100).reverse()));
app.post('/api/wallet/recharge',auth,(req,res)=>{
 const a=Math.round(Number(req.body.amount)*100);
 if(!Number.isFinite(a)||a<100||a>10000000)return res.status(400).json({error:'Invalid amount.'});
 const order={id:crypto.randomUUID(),userId:req.user.id,amountPaise:a,status:'pending',createdAt:Date.now()};
 db.paymentOrders.push(order);save();
 res.json({orderId:order.id,amount:a/100,status:'pending',message:'Payment order created. Credit wallet only after verified gateway webhook.'});
});
app.post('/api/payments/webhook',express.raw({type:'application/json'}),(req,res)=>{
 const secret=process.env.PAYMENT_WEBHOOK_SECRET;
 if(!secret)return res.status(503).json({error:'Payment webhook secret is not configured.'});
 const signature=String(req.headers['x-soultalk-signature']||'');
 const expected=crypto.createHmac('sha256',secret).update(req.body).digest('hex');
 if(!signature||signature.length!==expected.length||!crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected)))return res.status(401).json({error:'Invalid signature.'});
 let event;try{event=JSON.parse(req.body.toString('utf8'))}catch{return res.status(400).json({error:'Invalid JSON.'})}
 const o=db.paymentOrders.find(x=>x.id===event.orderId);if(!o)return res.status(404).json({error:'Order not found.'});
 if(o.status==='paid')return res.json({ok:true,idempotent:true});
 if(event.status!=='paid'||Number(event.amountPaise)!==o.amountPaise)return res.status(400).json({error:'Payment mismatch.'});
 o.status='paid';o.paidAt=Date.now();db.wallets[o.userId]=(db.wallets[o.userId]||0)+o.amountPaise;
 db.ledger.push({id:crypto.randomUUID(),userId:o.userId,type:'recharge',amountPaise:o.amountPaise,ref:o.id,at:Date.now()});save();
 res.json({ok:true,balance:(db.wallets[o.userId]||0)/100});
});
app.post('/api/host/apply',auth,(req,res)=>{if(req.user.hostStatus==='approved')return res.status(400).json({error:'Already a host.'});const age=Number(req.body.age);const upi=String(req.body.upi||'').trim().slice(0,120);if(!Number.isInteger(age)||age<18||age>100)return res.status(400).json({error:'Host must be 18+.'});if(!upi)return res.status(400).json({error:'UPI ID is required.'});req.user.name=String(req.body.name||req.user.name||'Host').slice(0,80);req.user.about=String(req.body.about||'').slice(0,300);req.user.hostApplication={age,upi,submittedAt:Date.now()};req.user.hostStatus='pending';save();res.json({ok:true})});
app.get('/api/host/status',auth,(req,res)=>{res.json({status:req.user.hostStatus||'none',name:req.user.name||'',about:req.user.about||'',decisionAt:req.user.hostDecisionAt||null})});
app.get('/api/hosts',auth,(req,res)=>res.json(db.users.filter(u=>u.hostStatus==='approved'&&u.id!==req.user.id).map(u=>({id:u.id,name:u.name,about:u.about,online:u.online===true}))));
app.post('/api/calls/start',auth,(req,res)=>{const h=db.users.find(u=>u.id===req.body.hostId&&u.hostStatus==='approved');if(!h||h.online!==true)return res.status(404).json({error:'Host is currently offline.'});if((db.wallets[req.user.id]||0)<500)return res.status(402).json({error:'Insufficient wallet balance. Recharge first.'});const c={id:crypto.randomUUID(),callerId:req.user.id,hostId:h.id,startAt:Date.now(),status:'ringing',acceptedAt:null};db.calls.push(c);save();io.to('user:'+h.id).emit('call:incoming',{callId:c.id,callerId:req.user.id,callerName:req.user.name||'SoulTalk User'});res.json({callId:c.id,ratePaise:500})});
function settleCall(c){
 const billStart=c.acceptedAt||c.startAt; const duration=c.acceptedAt?Math.max(0,Math.floor((Date.now()-billStart)/1000)):0;
 const balancePaise=db.wallets[c.callerId]||0;
 const affordableMinutes=Math.floor(balancePaise/500);
 const usedMinutes=duration===0?0:Math.min(Math.ceil(duration/60),affordableMinutes);
 const billableSeconds=usedMinutes*60;
 const b=billCall(billableSeconds);
 if(b.callerPaise>balancePaise)return {ok:false,error:'Insufficient wallet balance for final charge.'};
 db.wallets[c.callerId]-=b.callerPaise;
 db.wallets[c.hostId]=(db.wallets[c.hostId]||0)+b.hostPaise;
 if(b.callerPaise>0) db.ledger.push({id:crypto.randomUUID(),userId:c.callerId,type:'call_charge',amountPaise:-b.callerPaise,ref:c.id,at:Date.now()});
 if(b.hostPaise>0) db.ledger.push({id:crypto.randomUUID(),userId:c.hostId,type:'call_earning',amountPaise:b.hostPaise,ref:c.id,at:Date.now()});
 c.status='ended';c.endAt=Date.now();c.durationSeconds=duration;c.billableSeconds=billableSeconds;
 c.userCharge=b.callerPaise/100;c.hostEarning=b.hostPaise/100;c.minutes=b.minutes;c.billingLimited=billableSeconds<duration;
 return {ok:true,userCharge:c.userCharge,hostEarning:c.hostEarning,minutes:b.minutes};
}

app.post('/api/calls/end',auth,(req,res)=>{const c=db.calls.find(x=>x.id===req.body.callId&&x.callerId===req.user.id&&['ringing','active'].includes(x.status));if(!c)return res.status(404).json({error:'Active call not found.'});if(c.status==='ringing'){c.status='ended';c.endAt=Date.now();c.durationSeconds=0;c.billableSeconds=0;c.userCharge=0;c.hostEarning=0;c.minutes=0;c.billingLimited=false;save();io.to('call:'+c.id).emit('call:ended',{reason:'caller_cancelled',userCharge:0,hostEarning:0});return res.json({ok:true,userCharge:0,hostEarning:0,minutes:0});} const result=settleCall(c);if(!result.ok)return res.status(402).json({error:result.error});save();res.json(result)});
app.get('/api/calls',auth,(req,res)=>res.json(db.calls.filter(c=>c.callerId===req.user.id||c.hostId===req.user.id).sort((a,b)=>(b.endAt||b.startAt)-(a.endAt||a.startAt))));app.get('/api/host/earnings',auth,(req,res)=>{
 const host=req.user;if(host.hostStatus!=='approved')return res.status(403).json({error:'Host approval required.'});
 const earned=db.calls.filter(c=>c.hostId===host.id&&c.status==='ended').reduce((n,c)=>n+Math.round((c.hostEarning||0)*100),0);
 const withdrawn=db.withdrawals.filter(x=>x.hostId===host.id&&x.status!=='rejected').reduce((n,x)=>n+x.amountPaise,0);
 res.json({earnedPaise:earned,withdrawnPaise:withdrawn,availablePaise:Math.max(0,earned-withdrawn)});
});
app.post('/api/host/withdraw',auth,(req,res)=>{
 if(req.user.hostStatus!=='approved')return res.status(403).json({error:'Host approval required.'});
 const amount=Math.round(Number(req.body.amount)*100);if(!Number.isFinite(amount)||amount<10000)return res.status(400).json({error:'Minimum withdrawal is ₹100.'});
 const earned=db.calls.filter(c=>c.hostId===req.user.id&&c.status==='ended').reduce((n,c)=>n+Math.round((c.hostEarning||0)*100),0);
 const withdrawn=db.withdrawals.filter(x=>x.hostId===req.user.id&&x.status!=='rejected').reduce((n,x)=>n+x.amountPaise,0);
 if(amount>earned-withdrawn)return res.status(400).json({error:'Insufficient available earnings.'});
 const w={id:crypto.randomUUID(),hostId:req.user.id,amountPaise:amount,status:'pending',createdAt:Date.now()};db.withdrawals.push(w);save();
 res.json({withdrawalId:w.id,status:'pending',amount:amount/100,message:'Withdrawal queued for KYC/payout processing.'});
});
app.get('/api/admin/host-applications',auth,adminOnly,(req,res)=>res.json(db.users.filter(u=>u.hostStatus==='pending').map(({password,...u})=>u)));
app.post('/api/admin/host-applications/:id/decision',auth,adminOnly,(req,res)=>{const u=db.users.find(x=>x.id===req.params.id);if(!u)return res.status(404).json({error:'Host application not found.'});const decision=String(req.body.decision||'').trim().toLowerCase();if(decision==='approve'||decision==='approved'){u.hostStatus='approved';}else if(decision==='reject'||decision==='rejected'){u.hostStatus='rejected';}else{return res.status(400).json({error:'Decision must be approve/reject or approved/rejected.'});}u.hostDecisionAt=Date.now();save();res.json({ok:true,id:u.id,hostStatus:u.hostStatus})});
app.get('/api/admin/withdrawals',auth,adminOnly,(req,res)=>res.json(db.withdrawals));
app.get('/api/admin/reports',auth,adminOnly,(req,res)=>res.json(db.reports.slice(-200).reverse()));
app.post('/api/admin/reports/:id/decision',auth,adminOnly,(req,res)=>{const r=db.reports.find(x=>x.id===req.params.id);if(!r)return res.status(404).json({error:'Report not found.'});let decision=String(req.body.decision||'').trim().toLowerCase();if(decision==='resolve') decision='resolved';if(decision==='dismiss') decision='dismissed';if(!['resolved','dismissed'].includes(decision))return res.status(400).json({error:'Report decision must be resolve/dismiss or resolved/dismissed.'});if(r.status&&r.status!=='pending')return res.status(400).json({error:'Report already decided.'});r.status=decision;r.decidedAt=Date.now();save();res.json({ok:true,status:r.status})});
app.post('/api/admin/withdrawals/:id/decision',auth,adminOnly,(req,res)=>{const w=db.withdrawals.find(x=>x.id===req.params.id);if(!w)return res.status(404).json({error:'Withdrawal not found.'});let decision=String(req.body.decision||'').trim().toLowerCase();if(decision==='approve') decision='approved';if(decision==='reject') decision='rejected';if(!['approved','rejected'].includes(decision))return res.status(400).json({error:'Withdrawal decision must be approve/reject or approved/rejected.'});if(w.status!=='pending')return res.status(400).json({error:'Withdrawal already decided.'});w.status=decision;w.decidedAt=Date.now();w.payoutReference=String(req.body.payoutReference||'').slice(0,120);save();res.json({ok:true,status:w.status,payoutReference:w.payoutReference||null})});
app.get('/api/messages/:room',auth,(req,res)=>res.json(db.messages.filter(m=>m.room===req.params.room).slice(-100)));app.post('/api/report',auth,(req,res)=>{const room=String(req.body.room||'').trim().slice(0,120);const text=String(req.body.text||'').trim().slice(0,500);if(!text)return res.status(400).json({error:'Report reason is required.'});const recent=db.reports.find(r=>r.userId===req.user.id&&r.status==='pending'&&r.room===room&&Date.now()-r.at<30000);if(recent)return res.status(429).json({error:'A similar report was just submitted.'});db.reports.push({id:crypto.randomUUID(),userId:req.user.id,room,text,status:'pending',at:Date.now()});save();res.json({ok:true})});
app.delete('/api/account',auth,(req,res)=>{const id=req.user.id;db.users=db.users.filter(u=>u.id!==id);delete db.wallets[id];db.messages=db.messages.filter(m=>m.userId!==id);db.reports=db.reports.filter(r=>r.userId!==id);db.ledger=db.ledger.filter(x=>x.userId!==id);db.paymentOrders=db.paymentOrders.filter(x=>x.userId!==id);db.calls=db.calls.filter(c=>c.callerId!==id&&c.hostId!==id);db.withdrawals=db.withdrawals.filter(w=>w.hostId!==id);save();res.json({ok:true})});
// Server-side wallet guard: do not allow an active call to run past the caller's funded minutes.
setInterval(()=>{
 let changed=false;
 for(const c of db.calls.filter(x=>x.status==='ringing')){
  if(Date.now()-c.startAt>=45000){c.status='ended';c.endAt=Date.now();c.durationSeconds=0;c.billableSeconds=0;c.userCharge=0;c.hostEarning=0;c.minutes=0;c.billingLimited=false;io.to('user:'+c.callerId).emit('call:ended',{reason:'no_answer',userCharge:0,hostEarning:0});changed=true;continue;}
 }
 for(const c of db.calls.filter(x=>x.status==='active')){
  const elapsed=Math.max(0,Math.floor((Date.now()-c.startAt)/1000));
  const balancePaise=db.wallets[c.callerId]||0;
  if(elapsed>=Math.max(1,Math.floor(balancePaise/500))*60){
   const result=settleCall(c);
   if(result.ok){changed=true;io.to('call:'+c.id).emit('call:ended',{reason:'wallet_exhausted',...result});}
  }
 }
 if(changed)save();
},5000);

io.on('connection',socket=>{
socket.on('join',({token:t,room})=>{try{const p=jwt.verify(t,JWT_SECRET);socket.userId=p.id;socket.room=room;socket.join(room);socket.join('user:'+p.id);const u=db.users.find(x=>x.id===p.id);if(u&&u.hostStatus==='approved'&&u.online!==true){u.online=true;save();io.emit('host:presence',{userId:u.id,online:true})}}catch{socket.disconnect()}});
socket.on('message',m=>{if(!socket.userId||!socket.room)return;const x={id:crypto.randomUUID(),room:socket.room,userId:socket.userId,text:String(m.text||'').slice(0,1000),at:Date.now()};db.messages.push(x);save();io.to(socket.room).emit('message',x)});
socket.on('call:accept',({callId})=>{try{const c=db.calls.find(x=>x.id===callId&&x.status==='ringing'&&x.hostId===socket.userId);if(!c)return socket.emit('call:error','Call is no longer available.');c.status='active';c.acceptedAt=Date.now();save();io.to('call:'+c.id).emit('call:accepted',{callId:c.id});io.to('user:'+c.callerId).emit('call:accepted',{callId:c.id});}catch{socket.emit('call:error','Unable to accept call.')}});
socket.on('call:join',({callId,token:t})=>{try{const p=jwt.verify(t,JWT_SECRET);const c=db.calls.find(x=>x.id===callId&&x.status==='active'&&(x.callerId===p.id||x.hostId===p.id));if(!c)return socket.emit('call:error','Call is not active.');socket.userId=p.id;socket.callId=callId;socket.join('call:'+callId);socket.to('call:'+callId).emit('call:peer-joined');}catch{socket.emit('call:error','Unauthorized.')}});
socket.on('call:offer',data=>{if(socket.callId)socket.to('call:'+socket.callId).emit('call:offer',data)});
socket.on('call:answer',data=>{if(socket.callId)socket.to('call:'+socket.callId).emit('call:answer',data)});
socket.on('call:ice',data=>{if(socket.callId)socket.to('call:'+socket.callId).emit('call:ice',data)});
socket.on('disconnect',()=>{const id=socket.userId;if(!id)return;setTimeout(async()=>{try{const sockets=await io.in('user:'+id).fetchSockets();if(sockets.length===0){const u=db.users.find(x=>x.id===id);if(u&&u.online===true){u.online=false;save();io.emit('host:presence',{userId:id,online:false})}}}catch{}},0)});
socket.on('call:reject',({callId})=>{try{const c=db.calls.find(x=>x.id===callId&&['ringing','active'].includes(x.status)&&x.hostId===socket.userId);if(!c)return socket.emit('call:error','Call is not active.');c.status='ended';c.endAt=Date.now();c.durationSeconds=0;c.billableSeconds=0;c.userCharge=0;c.hostEarning=0;c.minutes=0;c.billingLimited=false;save();io.to('user:'+c.callerId).emit('call:ended',{reason:'host_rejected',userCharge:0,hostEarning:0});}catch{socket.emit('call:error','Unable to reject call.')}});
});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'..','public','index.html')));
function shutdown(signal){console.log('SoulTalk '+signal+' received; shutting down.');server.close(()=>process.exit(0));setTimeout(()=>process.exit(1),10000).unref()}
process.on('SIGTERM',()=>shutdown('SIGTERM'));process.on('SIGINT',()=>shutdown('SIGINT'));bootstrapAdmin().then(()=>server.listen(PORT,()=>console.log('SoulTalk server running on '+PORT))).catch(err=>{console.error('Admin bootstrap failed',err);process.exit(1)});
