# SoulTalk v23

- Added server-side wallet ledger entries for every completed/auto-ended call.
- Caller charge is recorded as `call_charge` (negative paise).
- Host earning is recorded as `call_earning` (positive paise).
- Ledger references the call ID for auditability and reconciliation.
- Existing server-authoritative billing and wallet-exhaustion auto-end remain unchanged.
