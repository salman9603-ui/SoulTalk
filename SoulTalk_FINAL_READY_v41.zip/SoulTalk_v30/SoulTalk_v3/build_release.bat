@echo off
set "API_BASE=%SOULTALK_API_BASE%"
if "%API_BASE%"=="" set "API_BASE=%~1"
if "%API_BASE%"=="" (
  echo ERROR: Set SOULTALK_API_BASE to an HTTPS production API URL.
  exit /b 2
)
if not exist gradlew.bat (
  echo ERROR: Gradle wrapper is missing. Open this project in Android Studio or install Gradle 8.7+.
  exit /b 4
)
call gradlew.bat :app:bundleRelease -PSOULTALK_API_BASE="%API_BASE%"
