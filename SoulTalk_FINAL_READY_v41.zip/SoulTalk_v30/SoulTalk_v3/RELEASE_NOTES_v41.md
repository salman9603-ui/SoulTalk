SoulTalk v41 — build handoff improvement
- Added BUILD_AAB.md with exact release build requirements and output path.
- Added check_build_environment.sh to detect Java, Gradle and Android SDK readiness.
- Keystore/passwords are explicitly kept outside the project package.
- No fake AAB/APK generated; source remains the release base until a real Android build environment is available.
