# SoulTalk v36 / 3.3.0

- Added server-authoritative host online/offline presence.
- `/api/hosts` now reports real socket-backed presence instead of always claiming hosts are online.
- Call start now rejects offline hosts.
- Host call list disables the Call button when the host is offline.
- Host presence changes refresh the caller's host list in real time.
- Android bundled frontend synchronized with the main frontend.
- Android versionCode 33 / versionName 3.3.0.

This is still not a production payment/voice deployment: real payment gateway, HTTPS deployment, TURN/provider credentials, and signed AAB remain external release requirements.
