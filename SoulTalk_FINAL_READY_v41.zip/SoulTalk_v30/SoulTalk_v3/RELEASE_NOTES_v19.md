# SoulTalk v19

- Added the `/api/host/status` endpoint used by the Host Dashboard.
- Admin withdrawal decisions now persist the payout reference.
- Kept approve/reject aliases for the admin UI.
