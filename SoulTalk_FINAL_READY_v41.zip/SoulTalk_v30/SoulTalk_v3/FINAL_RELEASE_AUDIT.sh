#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SERVER="$ROOT/server/server.js"
APP="$ROOT/app/build.gradle"
HTML="$ROOT/public/index.html"
node --check "$SERVER"
python - <<'PY' "$SERVER" "$APP" "$HTML" "$ROOT"
from pathlib import Path
server, app, html, root = map(Path, __import__('sys').argv[1:])
s=server.read_text(); g=app.read_text(); h=html.read_text()
checks={
 'health endpoint': "app.get('/api/health'" in s,
 'auth': "app.post('/api/login'" in s and "app.post('/api/register'" in s,
 'verified payment webhook': "PAYMENT_WEBHOOK_SECRET" in s and "timingSafeEqual" in s,
 'server-authoritative billing': "Date.now()-c.startAt" in s and "app.post('/api/calls/end'" in s,
 'host status': "app.get('/api/host/status'" in s,
 'admin host decision': "admin/host-applications/:id/decision" in s,
 'admin withdrawal decision': "admin/withdrawals/:id/decision" in s,
 'report moderation': "admin/reports/:id/decision" in s,
 'wallet exhaustion guard': "wallet_exhausted" in s,
 'release HTTPS guard': "startsWith('https://')" in g,
 'Android audio permission': 'RECORD_AUDIO' in (root/'app/src/main/java/com/soultalk/app/MainActivity.java').read_text(),
 'voice signaling': "call:offer" in s and "call:answer" in s and "call:ice" in s,
 'account deletion': "app.delete('/api/account'" in s,
 'UI app': 'SoulTalk' in h,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
if failed: raise SystemExit('FAILED: '+', '.join(failed))
print('FINAL RELEASE AUDIT: PASS')
PY
