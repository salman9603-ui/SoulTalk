# SoulTalk v20

- Fixed low-wallet long-call edge case: a call can no longer remain active because the final charge exceeds the caller's remaining wallet.
- Server calculates the affordable billable duration from wallet balance and marks `billingLimited` when the requested duration exceeded the paid duration.
- Billing remains server-authoritative; the client timer is display-only.
