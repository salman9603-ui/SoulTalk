# SoulTalk v38 Release Notes

## Call rejection fix
- Host rejection now works while a call is still `ringing` as well as after activation.
- Rejected/unanswered calls remain non-billable.
- Server remains authoritative for billing; only accepted calls can accrue billable duration.

## Release consistency
- Node server package version aligned to Android release version 3.4.0.

## Verification
- `server/server.js` syntax check: PASS
- Billing module load/test: PASS
- ZIP integrity: PASS
