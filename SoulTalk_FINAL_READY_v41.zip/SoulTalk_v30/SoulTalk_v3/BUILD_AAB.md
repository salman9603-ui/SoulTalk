# SoulTalk AAB Build

## Required
- JDK 17 or 21
- Android SDK Platform 35
- Android SDK Build-Tools
- Gradle 8.7+ (or use Android Studio's Gradle tooling)
- A real HTTPS backend URL

## Build
From this directory:

```bash
gradle :app:bundleRelease -PSOULTALK_API_BASE=https://YOUR-API-DOMAIN
```

The release build rejects non-HTTPS API URLs.

## Signing
Create a private upload/release keystore outside the project and provide signing values through your secure build environment. Never commit the keystore or passwords to Git or this ZIP.

## Output
`app/build/outputs/bundle/release/app-release.aab`
