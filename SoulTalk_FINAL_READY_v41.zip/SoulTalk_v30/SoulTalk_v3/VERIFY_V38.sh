#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
node --check "$ROOT/server/server.js"
node - <<'NODE'
const {billCall}=require('./../production_backend/call_billing');
const a=billCall(1), b=billCall(60), c=billCall(61);
if(a.callerPaise!==500 || a.hostPaise!==200) throw new Error('1-second billing mismatch');
if(b.callerPaise!==500 || b.hostPaise!==200) throw new Error('60-second billing mismatch');
if(c.callerPaise!==1000 || c.hostPaise!==400) throw new Error('61-second billing mismatch');
console.log('billing: PASS');
NODE
echo 'server syntax: PASS'
