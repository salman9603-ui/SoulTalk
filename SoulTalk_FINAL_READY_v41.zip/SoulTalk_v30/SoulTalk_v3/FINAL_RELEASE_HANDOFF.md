# SoulTalk Final Release Handoff

## Current source status
- Android version: 3.2.0 (versionCode 32)
- Authentication, profile, chat, wallet, host discovery, host application, admin moderation, call billing and account deletion are included.
- Call charging is server-authoritative and uses started-minute billing at ₹5/min; approved hosts receive ₹2/min.
- Payment webhook is signature-checked and idempotent, but a live payment provider is not configured.
- WebRTC signaling is included, but production STUN/TURN or a managed voice provider is still required for reliable internet calling.

## Required before Play Store production
1. Deploy the backend behind HTTPS.
2. Configure JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD, CORS_ORIGIN and PAYMENT_WEBHOOK_SECRET.
3. Connect a real payment provider and verify its webhook contract.
4. Configure production STUN/TURN or a voice provider.
5. Use a transactional production database/ledger rather than the file-backed development store.
6. Build a signed release AAB with `SOULTALK_API_BASE=https://...`.
7. Complete Play Console testing, policy declarations, privacy/data-safety information and store listing.

## Local verification
Run `node --check` on all JavaScript files and `python -m json.tool` on JSON files. The release build script intentionally refuses non-HTTPS API URLs and requires the Gradle wrapper/Android Studio environment.
