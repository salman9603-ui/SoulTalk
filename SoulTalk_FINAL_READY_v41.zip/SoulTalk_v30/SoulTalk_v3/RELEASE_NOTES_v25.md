# SoulTalk v25

- Fixed host application persistence for age and UPI.
- Added server validation for 18+ host applications.
- Added admin reports review endpoint and dashboard section.
- Admin host dashboard now displays submitted host verification details.
- Mirrored frontend assets kept in sync.
