# SoulTalk v4
Talk. Share. Feel understood.

Features: authentication, realtime chat, profiles, safety/reporting, wallet, recharge demo, host directory, per-minute voice-call billing ledger and host earnings.

Business rule configured in this prototype: user charge ₹5/min and host earning ₹2/min. GST/payment fees must be integrated and configured according to the applicable legal/tax/payment setup before production launch.

For production: use HTTPS, PostgreSQL/Supabase/Firebase, real voice calling (WebRTC/approved provider), real payment gateway/Play Billing as applicable, server-side billing, KYC/payout provider, moderation, privacy policy, terms, account deletion and Play Store compliance.
