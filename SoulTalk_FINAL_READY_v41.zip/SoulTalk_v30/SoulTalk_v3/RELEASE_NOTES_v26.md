# SoulTalk v26

- Normalized backend data collections at startup so older `data.json` files missing optional arrays do not crash routes.
- Account deletion now removes the user's profile-linked messages, reports, ledger entries, payment orders, calls, and withdrawal records along with the wallet.
- Existing call billing, wallet exhaustion guard, host verification, admin approval, and report review flows remain intact.
- Backend JavaScript syntax check: PASS.
