# SoulTalk production API deployment

1. Copy `server/.env.example` to `server/.env`.
2. Set strong `JWT_SECRET`, `PAYMENT_WEBHOOK_SECRET`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, and the production `CORS_ORIGIN`.
3. Put the API behind HTTPS (reverse proxy/load balancer) before the Android release build.
4. Run `docker compose -f docker-compose.production.yml up -d --build`.
5. Verify `/api/health`.
6. Configure the real payment gateway to call `/api/payments/webhook` with the HMAC contract documented in the payment setup guide.
7. Back up the persistent data volume and plan migration to PostgreSQL before high-volume production.

Important: this package still uses the lightweight JSON ledger. It is suitable for integration/testing, not a high-volume financial production deployment.
