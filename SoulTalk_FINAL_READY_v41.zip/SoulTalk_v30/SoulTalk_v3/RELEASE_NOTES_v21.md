# SoulTalk v21

- Added a reusable server-side call settlement function.
- Added a server-side wallet exhaustion guard that automatically ends funded calls when the caller has used the funded minutes.
- Call-end billing remains based on server time; the client cannot choose the billed duration.
