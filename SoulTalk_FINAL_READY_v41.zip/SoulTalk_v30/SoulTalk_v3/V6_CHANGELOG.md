# SoulTalk V6

Added:
- Host application flow from the app.
- Admin-only overview endpoint.
- Admin host approval endpoint.
- Host approval changes the account role to `host`.
- Host earning/call ledger remains server-side.

Production blockers before real-money launch:
- Replace file JSON with a real database.
- Integrate a real voice/video provider and server-side call events.
- Integrate a compliant payment/recharge flow and verified webhooks.
- Implement KYC/payout provider for host withdrawals.
- Configure tax/GST treatment with professional advice.
- Add Play Billing where required for Android digital purchases.
