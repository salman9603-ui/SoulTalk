# SoulTalk v40

- Added Play Store release signing configuration driven by environment variables / Gradle properties.
- Signing is opt-in via `SOULTALK_SIGNING=true`; no secrets or keystore are bundled.
- Added `PLAY_STORE_SIGNING.md` with the exact AAB build command.
- Existing HTTPS API release guard remains enabled.
