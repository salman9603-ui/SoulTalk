# SoulTalk v30

Clean release source package.

- Consolidated the canonical SoulTalk Android/WebView app and backend into one clean package.
- Preserved host status, admin reports, withdrawal approval, wallet and server-authoritative call billing flows.
- Removed temporary build/test files and duplicate historical source trees from the distributable ZIP.
- Real payment provider, production voice provider/TURN, production database, and signed Play Store AAB still require external production credentials/infrastructure.
