# SoulTalk Final Release Status

## Source status
The Android/WebView source and Node.js backend are packaged and statically audited.

## Included
- Authentication and profiles
- Wallet ledger and verified-payment webhook contract
- Server-authoritative call billing at ₹5/min started-minute rate
- Host earnings at ₹2/min
- Host application/18+ validation and admin moderation
- Withdrawal workflow and admin decision handling
- Reports and moderation
- WebRTC signaling hooks
- Android release HTTPS API guard
- Account deletion and release verification scripts

## External release blockers
A production launch still requires real third-party configuration: payment gateway credentials/webhook, voice/STUN/TURN or voice provider, production HTTPS hosting, KYC/payout provider, privacy/legal documents, and a signed Android AAB.

No credentials or live services are embedded in this source package.
