const CALL_RATE_PAISE = 500;       // ₹5/min caller charge
const HOST_EARNING_PAISE = 200;    // ₹2/min host earning

function calculateCallBilling(durationSeconds) {
  const seconds = Math.max(0, Number(durationSeconds) || 0);
  const minutes = seconds === 0 ? 0 : Math.ceil(seconds / 60);

  return {
    minutes,
    callerChargePaise: minutes * CALL_RATE_PAISE,
    hostEarningPaise: minutes * HOST_EARNING_PAISE
  };
}

module.exports = {
  CALL_RATE_PAISE,
  HOST_EARNING_PAISE,
  calculateCallBilling
};
