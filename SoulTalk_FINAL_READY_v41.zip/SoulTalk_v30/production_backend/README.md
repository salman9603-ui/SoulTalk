# SoulTalk V7 Production Integration

This package moves the project toward the actual paid-calling architecture.

Still required before live money:
- Deploy backend over HTTPS.
- Use a production database and immutable wallet ledger.
- Integrate a real voice provider (WebRTC/Agora/Twilio or equivalent).
- Integrate a compliant payment provider and verify webhooks server-side.
- For Android digital goods, implement the applicable Google Play Billing flow.
- Implement KYC/payout provider for host withdrawals.
- Configure GST/tax/refund rules with a qualified professional.
- Add rate limiting, fraud detection, moderation and audit logs.
- Keep API keys/secrets only on the server.

The included billing reference uses ₹5/min caller charge and ₹2/min host earning,
with money represented in paise and rounding to started minutes.
