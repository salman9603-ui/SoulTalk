const express = require("express");
const { calculateCallBilling } = require("./callBilling");

const router = express.Router();

router.post("/calls/quote", (req, res) => {
  const seconds = Number(req.body?.durationSeconds);
  if (!Number.isFinite(seconds) || seconds < 0 || seconds > 24 * 60 * 60) {
    return res.status(400).json({ error: "Invalid duration" });
  }

  res.json(calculateCallBilling(seconds));
});

module.exports = router;
