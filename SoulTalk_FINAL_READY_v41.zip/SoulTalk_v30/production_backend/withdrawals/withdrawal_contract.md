# Host Withdrawal Contract

POST /api/withdrawals
GET  /api/withdrawals
POST /api/admin/withdrawals/{id}/approve

Rules:
- Host must pass required verification/KYC.
- Minimum withdrawal configured by admin.
- Balance is reserved atomically before payout.
- Payout status is updated from verified provider callbacks.
- Every action gets an audit record.
