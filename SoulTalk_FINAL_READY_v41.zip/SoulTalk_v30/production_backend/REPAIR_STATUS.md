SOULTALK V13 REPAIR

Fixed:
- Clean server-side billing module
- ₹5/min caller rate represented as 500 paise
- ₹2/min host earning represented as 200 paise
- Server-side duration validation
- Call quote API contract

Important:
This is still an integration-ready development build. Real money must only be charged
after authenticated call sessions and verified payment/wallet transactions are wired
to production services. Client-side timers are not trusted for billing.
