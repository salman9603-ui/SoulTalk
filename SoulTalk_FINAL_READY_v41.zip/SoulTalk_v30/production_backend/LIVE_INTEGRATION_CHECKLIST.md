SOULTALK V8 LIVE INTEGRATION CHECKLIST

[ ] HTTPS production API
[ ] PostgreSQL/Supabase production database
[ ] JWT/session security and refresh/revocation
[ ] Real voice calling provider
[ ] Server-side call start/end and duration verification
[ ] Payment provider + signed webhook verification
[ ] Google Play Billing for applicable Android digital purchases
[ ] Host KYC and payout provider
[ ] GST/tax/refund configuration reviewed professionally
[ ] Fraud/rate limiting/device abuse controls
[ ] Admin authentication + audit log
[ ] Privacy Policy / Terms / Refund Policy / Community Guidelines
[ ] Account deletion flow
[ ] Play Store Data Safety declarations
[ ] Production crash/error monitoring

MONEY RULE
₹5/min = 500 paise gross caller charge.
₹2/min = 200 paise host earning.
The remaining ₹3/min is NOT automatically profit: applicable GST/taxes,
payment fees, refunds and other costs must be accounted for separately.
