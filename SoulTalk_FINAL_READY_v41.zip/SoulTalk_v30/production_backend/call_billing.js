
// Server-side reference implementation for SoulTalk paid calls.
// Money is stored in paise. The client must never decide the final charge.
const RATE = 500;       // ₹5.00 / started minute
const HOST_EARNING = 200; // ₹2.00 / started minute

function billCall(durationSeconds) {
  const seconds = Math.max(0, Number(durationSeconds) || 0);
  if (seconds === 0) return { minutes: 0, callerPaise: 0, hostPaise: 0 };
  const minutes = Math.ceil(seconds / 60);
  return {
    minutes,
    callerPaise: minutes * RATE,
    hostPaise: minutes * HOST_EARNING
  };
}

module.exports = { billCall };
