# Voice Call Service Contract

POST /api/calls/start
- authenticated caller
- host must be approved and online
- server checks wallet balance
- creates call session

POST /api/calls/{id}/end
- authenticated participant
- server derives duration
- server calculates charge and host earning
- writes immutable ledger entries

The actual media transport must be supplied by a production voice provider/WebRTC service.
Never expose provider secrets in the Android client.
