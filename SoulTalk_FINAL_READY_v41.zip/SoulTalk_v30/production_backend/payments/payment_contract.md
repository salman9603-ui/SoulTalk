# Payment Contract

POST /api/recharge/create
POST /api/payments/webhook
GET  /api/wallet

Rules:
- Create orders on the server.
- Verify signed payment callbacks on the server.
- Credit wallet only after verified payment success.
- Make webhook processing idempotent.
- Store all money as integer paise.
- Never accept a client-provided wallet balance.
